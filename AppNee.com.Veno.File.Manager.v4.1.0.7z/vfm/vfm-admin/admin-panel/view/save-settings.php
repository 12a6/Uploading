<div class="row mb-3">
    <div class="col-sm-12">
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="bi bi-arrow-repeat"></i> <?php print $setUp->getString("save_settings"); ?>
            </button>
        </div>
    </div>
</div>
<div class="fixed-label d-none">
    <button type="submit" class="btn btn-primary rounded-0" title="<?php echo $setUp->getString("save_settings"); ?>">
        <i class="bi bi-arrow-repeat"></i> 
    </button>
</div>